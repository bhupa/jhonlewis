<?php $__env->startSection('title','Order-Lists'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- breadcrumb-->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li aria-current="page" class="breadcrumb-item"><a href="<?php echo e(route('order-lists.index')); ?>">My orders</a></li>
                                <li aria-current="page" class="breadcrumb-item active">Order # 1735</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-lg-3">

                        <?php echo $__env->make('profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </div>
                    <div id="customer-order" class="col-lg-9">
                        <table class="table text-center" id="table">
                            <thead class="text-uppercase bg-primary">
                            <tr class="text-white">
                                <th scope="col">ID</th>
                                <th scope="col">Serial Number</th>
                                <th scope="col">Date</th>
                                <th scope="col">Items</th>
                                <th scope="col">Shipping</th>
                                <th scope="col">Amount</th>
                                <th scope="col">action</th>
                            </tr>
                            </thead>
                            <tbody id="sortable">
                            <?php $totalAmout=0; $totalquantity=0;?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="item-<?php echo e($item->id); ?>">
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($item->serial_number); ?></td>
                                    <td>
                                        <?php echo e(date('d-M-Y', strtotime($item->created_at))); ?>

                                    </td>
                                    <td><?php echo e($item->total_item); ?></td>
                                    <td>£ &nbsp;<?php echo e($item->shipping_amount); ?></td>
                                    <td>£ &nbsp;<?php echo e($item->total_amount); ?></td>
                                    <td>
                                        <?php $totalAmout +=  $item->total_amount ?>
                                        <?php $totalquantity +=  $item->total_item ?>
                                        <a href="<?php echo e(route('order-lists.show', [$item->id])); ?>" class="edit-modal btn btn-info btn-circle btn-sm"
                                           data-info="">
                                            <i class="fa fa-eye"></i>
                                        </a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot style="background: #ffffff">
                            <tr>

                                <td colspan="3">Total:</td>
                                <td colspan=""><?php echo e($totalquantity); ?></td>
                                <td></td>
                                <td>£ <?php echo e(number_format((float)$totalAmout, 2, '.', '')); ?></td>
                                <td></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>