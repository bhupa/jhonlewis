<?php $__env->startSection('title','Add-Product'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>"> View Product</a></li>
                            <li class="breadcrumb-item active">Dashboard </li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-8 ">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Add Product</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <?php echo Form::open(['route'=>'products.store','class'=>'needs-validation"','enctype'=>   "multipart/form-data",'id'=>'product-store']); ?>


                            <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Title</label>
                                        <input type="text" class="form-control" name="title" placeholder="Enter Title" value="<?php echo e(old('title')); ?>">

                                        <?php if($errors->has('title')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Type</label>
                                            <select name="type" class="form-control">
                                                <option value="0">Select Type</option>
                                                <option value="eye-wear" <?php echo e((old('type')== 'eye-wear')? 'selected':''); ?>>Eye Wear</option>
                                                
                                                <option value="sunglass" <?php echo e((old('type')== 'sunglass')? 'selected':''); ?>>Sunglass</option>

                                            </select>
                                            <?php if($errors->has('type')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Gender</label>
                                            <select name="gender" class="form-control">
                                                <option value="0">Select gender</option>
                                                <option value="men" <?php echo e((old('gender')== 'men')? 'selected':''); ?>>Men</option>
                                                
                                                <option value="women" <?php echo e((old('gender')== 'women')? 'selected':''); ?>>Women</option>

                                            </select>
                                            <?php if($errors->has('type')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Brand </label>
                                            <select name="brand_id" class="form-control" id="frame_id">
                                                <option value="">Select Brand </option>

                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('brand_id')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('brand_id')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="exampleInputEmail1">Model</label>
                                            <input type="text" class="form-control" name="shape" placeholder="Enter Model" value="<?php echo e(old('shape')); ?>">

                                            <?php if($errors->has('shape')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('shape')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        
                                            
                                            

                                            
                                            
                                                
                                            
                                        
                                    </div>


                                </div>
                                
                                    
                                        
                                            
                                            
                                                

                                                
                                                    
                                                
                                            
                                            
                                                
                                            
                                        

                                        
                                            
                                            
                                                

                                                
                                                    
                                                
                                            
                                            
                                                
                                            
                                        

                                    

                                
                                
                                   
                                       
                                           
                                           
                                               

                                               
                                                   
                                               
                                           
                                           
                                               
                                           
                                       

                                       
                                           
                                           
                                               

                                               
                                                   
                                               
                                           
                                           
                                               
                                           
                                       
                                   

                                
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Price</label>
                                            <input type="text" class="form-control" name="price" placeholder="Price" value="<?php echo e(old('price')); ?>">
                                            <?php if($errors->has('price')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Warrranty</label>
                                            <input type="text" class="form-control" name="warranty" placeholder="Warranty" value="<?php echo e(old('warranty')); ?>">

                                        <?php if($errors->has('wrranty')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('wrranty')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        
                                            
                                            
                                            
                                                
                                            
                                        

                                        <div class="col-md-6 mb-3">
                                            <label for="validationCustom01">Size</label>
                                            <input type="text" class="form-control" name="size" placeholder="Size" value="<?php echo e(old('size')); ?>">

                                            <?php if($errors->has('size')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('size')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                        <label for="validationCustom01">Discount</label>
                                        <select name="discount_id" class="form-control">
                                        <option value="">Select Discount</option>

                                        <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('discount_id')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('discount_id')); ?></span>
                                        <?php endif; ?>
                                        </div>
                                        
                                            
                                                
                                                
                                            
                                            
                                                
                                            
                                        
                                    </div>

                                </div>
                                
                                    
                                        
                                            
                                            
                                            
                                                
                                            
                                        

                                        
                                            
                                                
                                                
                                            
                                            
                                                
                                            
                                        
                                    

                                

                                <div class="form-group">
                                        <label for="exampleInputFile">Upload Image</label>
                                        <div class="upload-btn-wrapper">
                                            <button type="button" class="btn">Upload a file</button>
                                            <input type="file" class="form-control" accept="image/*" id="upload-image" name="image">

                                        </div>
                                        <?php if($errors->has('image')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                        <?php endif; ?>

                                    </div>
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                

                                <div class="form-group">
                                    <div class="custom-control form-control-lg custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="shipping" id="customCheck1">
                                        <label class="custom-control-label" for="customCheck1">Shipping</label>
                                    </div>
                                    
                                    
                                                                            
                                    
                                        
                                    
                                </div>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>

                </div>

                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>


        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js_script'); ?>
            <script>
                $(document).ready( function () {
                    $('#upload-image').on('change',function(){

                        readImgUrlAndPreview(this);
                        function readImgUrlAndPreview(input){
                            $('#output').css('display','block');
                            $('.cover').css('display','block');
                            if (input.files && input.files[0]) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    $('#output').attr('src', e.target.result);
                                }
                            };
                            reader.readAsDataURL(input.files[0]);
                        }
                    })

                    $('#clear-image').on('click',function(){
                        var logo = $('#upload-image-details').attr('data-logo');

                        if(logo == 1){
                            $('#upload-image-details').attr('data-image','0');
                            $( '#upload-image-details').css('margin-bottom','200px');
                        }
                        else{
                            $('#upload-image-details').attr('data-image','0');
                            $( '#upload-image-details').css('margin-bottom','0px');
                        }
                        $('#output').css('display','none');
                        $('.cover').css('display','none');
                        $('#output').attr('src', '');
                    })
                    $("#product-store").on("change","#frame_id", function(){
                        var id = $( "#frame_id option:selected" ).val();;
                        var url = "<?php echo e(route('frames.get-category')); ?>";

                        broker(id, url )
                    })
                    function broker(id, url ){
                        $.ajax({
                            type:'post',
                            url:url,
                            data:{id:id},
                            dataType:'json',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success:function(response){

                                if(response.success == true){
                                    var value = response.categories;
                                    var option = '';
                                    // option  +='<option selected="selected" value="0">Select Frame Category</option:selectedoption>';
                                    $.each(value, function(key, value) {

                                        option  +='<option selected="selected" value="'+value.id+'">'+value.name+'</option:selectedoption>';
                                    });
                                    // option  +='<option selected="selected" value="0">Select Frame Category</option:selectedoption>';
                                    $('#frame_category_id').html(option);
                                }else{
                                    $('#frame_category_id').empty();
                                }
                            }
                        })
                    }

                });
            </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>