<?php $__env->startSection('title','Order-Lists-show'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- breadcrumb-->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li aria-current="page" class="breadcrumb-item">My orders</li>
                                <li aria-current="page" class="breadcrumb-item active"><?php echo e($orders->serial_number); ?></li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-lg-3">

                        <?php echo $__env->make('profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </div>
                    <div id="customer-order" class="col-lg-9">
                        <div class="box">
                            <p class="lead">Order <?php echo e($orders->serial_number); ?> was placed on <strong><?php echo e(date('d-m-Y', strtotime($orders->created_at))); ?></strong> and is currently <strong>Being prepared</strong>.</p>
                            <p class="text-muted">If you have any questions, please feel free to <a href="<?php echo e(route('contact-us.index')); ?>">contact us</a>, our customer service center is working for you 24/7.</p>
                            <hr>
                            <div class="table-responsive mb-4">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th >Product</th>
                                        <th>Color</th>
                                        <th>Received</th>
                                        <th>Return</th>
                                        <th>Piece</th>
                                        <th>Unit price</th>
                                        <th>Discount</th>
                                        <th>Total</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $totalAmout=0; $totalquantity=0;?>
                                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href="<?php echo e(route('product.show',[$sale->product->slug])); ?>"><img src="https://d19m59y37dris4.cloudfront.net/obaju/2-1-1/img/detailsquare.jpg" alt="White Blouse Armani"></a></td>
                                        <td><a href="<?php echo e(route('product.show',[$sale->product->slug])); ?>"><?php echo e($sale->product->title); ?>}</a></td>
                                        <td><?php echo e($sale->stock->color->name); ?></td>
                                        <td>
                                            <?php if($sale->dispatch == '1'): ?>
                                                <span class="badge badge-success">received</span>
                                                <?php else: ?>
                                                <span class="badge badge-warning">not-received</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php if($sale->return == '1'): ?>
                                                <span class="badge badge-danger">Cancelled</span>
                                                <?php else: ?>
                                            <span class="badge badge-success">not return</span>
                                                <?php endif; ?>
                                        </td>
                                        <td><?php echo e($sale->piece); ?></td>
                                        <td>£ &nbsp;<?php echo e($sale->unit_price); ?></td>
                                        <td>£ &nbsp;<?php echo e($sale->discount_amount); ?></td>
                                        <td>£ &nbsp;<?php echo e($sale->price); ?></td>
                                    </tr>
                                    <?php $totalAmout +=  $sale->price?>
                                    <?php $totalquantity +=  $sale->piece ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th colspan="8" class="text-right">Order subtotal</th>
                                        <th><?php echo e($totalAmout); ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="8" class="text-right">Shipping and handling</th>
                                        <th><?php echo e($orders->shipping_amount); ?></th>
                                    </tr>

                                    <tr>
                                        <th colspan="8" class="text-right">Total</th>
                                        <th><?php echo e($orders->total_amount); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.table-responsive-->
                            <div class="row addresses">
                                <div class="col-lg-6">
                                    <h2>Invoice address</h2>
                                    <p><?php echo e(auth()->user()->name); ?><br><?php echo e(auth()->user()->address); ?><br><?php echo e(auth()->user()->country); ?><br><?php echo e(auth()->user()->phone); ?><br><?php echo e(auth()->user()->email); ?></p>
                                </div>
                                <div class="col-lg-6">
                                    <h2>Shipping address</h2>
                                    <p><?php echo e($orders->shipping->first_name); ?> &nbsp;<?php echo e($orders->shipping->last_name); ?><br>1<?php echo e($orders->shipping->street); ?><br><?php echo e($orders->shipping->address); ?><br><?php echo e($orders->shipping->phone); ?><br><?php echo e($orders->shipping->email); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>