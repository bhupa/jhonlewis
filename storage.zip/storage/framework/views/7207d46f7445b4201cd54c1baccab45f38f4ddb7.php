<ul class="navbar-nav mr-auto desktop-menu" id="menu">

    <li class="nav-item"> <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e((request()->segment(1) == '') ? 'active' : ''); ?>">Home</a></li>


    <li class="nav-item"> <a href="<?php echo e(route('content.show',['about-us'])); ?>" class="nav-link <?php echo e((request()->segment(2) == 'about-us') ? 'active' : ''); ?>">About Us</a></li>

    <li class="nav-item"> <a href="<?php echo e(route('service.index')); ?>" class="nav-link <?php echo e((request()->segment(1) == 'service') ? 'active' : ''); ?>">Services</a></li>
    <li class="nav-item"> <a href="<?php echo e(route('content.show',['eye-care'])); ?>" class="nav-link <?php echo e((request()->segment(2) == 'eye-care') ? 'active' : ''); ?>">Eye Care</a></li>
    <li class="nav-item"> <a href="<?php echo e(route('content.show',['frame-brand'])); ?>" class="nav-link <?php echo e((request()->segment(2) == 'frame-brand') ? 'active' : ''); ?>">Frames & Brands</a>
    <li class="nav-item"> <a href="<?php echo e(route('content.show',['contact-lens'])); ?>" class="nav-link <?php echo e((request()->segment(2) == 'contact-lens') ? 'active' : ''); ?>">Contact Lens</a></li>


        
            
                

            
        
    
    
    
    <li class="nav-item"> <a href="<?php echo e(route('shop.index')); ?>" class="nav-link <?php echo e((request()->segment(1) == 'shop') ? 'active' : ''); ?>">Shop Online</a></li>
   
    <li class="nav-item"> <a href="<?php echo e(route('contact-us.index')); ?>" class="nav-link <?php echo e((request()->segment(1) == 'contact-us') ? 'active' : ''); ?>">Contact Us</a></li>

    
        
            
            

        

    
    
    
        
            
            
            
        
    
    
        
            
            
            
        
    
    

        

            
                
                    
                        

                    
                
                    
                        
                            
                        

                        
                            
                                
                                
                            
                        
                    

                
                
        
    
    
        
            
            
            
        
    

</ul>


