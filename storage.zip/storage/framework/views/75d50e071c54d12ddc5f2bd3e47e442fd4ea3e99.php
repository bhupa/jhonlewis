<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- breadcrumb-->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li aria-current="page" class="breadcrumb-item active">Register</li>
                            </ol>
                        </nav>
                    </div>
                    
                        
                    
                    <div class="col-lg-12">
                        <div class="box">
                            <h1>New account</h1>
                            <p class="lead">Not our registered customer yet?</p>
                            <p>With registration with us new world of fashion, fantastic discounts and much more opens to you! The whole process will not take you more than a minute!</p>
                            <p class="text-muted">If you have any questions, please feel free to <a href="<?php echo e(route('contact-us.index')); ?>">contact us</a>, our customer service center is working for you 24/7.</p>
                            <hr>
                         <?php echo Form::open(['router'=>'register.store','method'=>'post']); ?>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name">Name</label>
                                            <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>">
                                            <?php if($errors->has('name')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="email">Email</label>
                                            <input id="email" name="email" type="email" class="form-control"  value="<?php echo e(old('email')); ?>">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="address">Address</label>
                                            <input id="text" name="address" type="text" class="form-control"  value="<?php echo e(old('address')); ?>">
                                            <?php if($errors->has('address')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="contact">Contact</label>
                                            <input id="text" name="contact" type="text" class="form-control"  value="<?php echo e(old('contact')); ?>">
                                            <?php if($errors->has('contact')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('contact')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="address">Postal Code</label>
                                        <input id="text" name="postal_code" type="text" class="form-control"  value="<?php echo e(old('postal_code')); ?>">
                                        <?php if($errors->has('postal_code')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('postal_code')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="contact">Zip Code</label>
                                        <input id="text" name="zip_code" type="text" class="form-control"  value="<?php echo e(old('zip_code')); ?>">
                                        <?php if($errors->has('zip_code')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('zip_code')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="password">Password</label>
                                            <input id="password" name="password" type="password" class="form-control"  value="<?php echo e(old('password')); ?>">
                                            <?php if($errors->has('password')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="password">Confirm-Password</label>
                                            <input id="confirm" name="confirm" type="password" class="form-control"  value="<?php echo e(old('confirm')); ?>">
                                            <?php if($errors->has('confirm')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('confirm')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>

                                <div class="text-left">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-user-md"></i> Register</button>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                    <!-- /.col-md-9-->

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>