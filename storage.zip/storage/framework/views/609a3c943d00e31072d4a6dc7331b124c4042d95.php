<?php $__env->startSection('title','Shopping Lists'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="row">
                <div class="col-md-12">
                    <div id="main-slider" class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="banner-wrapper">
                                    <img src="<?php echo e(asset('storage/'.$banner->image)); ?>" alt="<?php echo e($banner->title); ?>" class="img-fluid">
                                    <div class="banner-content">
                                        
                                        
                                        
                                        
                                        
                                        
                                    </div>


                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /#main-slider-->
                </div>
            </div>
            <div class="container">
                <div class="brand-listing">
                    <div class="row">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <a href="<?php echo e(route('brands.show',[$brand->slug])); ?>">
                                <div class="card">
                                    <div class="card-img-actions ">
                                        <img class="card-img img-fluid" src="<?php echo e(asset('storage/'.$brand->image)); ?>" alt="<?php echo e($brand->name); ?>" style=" height:200px;">

                                        <div class="card-img-actions-overlay card-img">
                                            

                                            
                                            

                                            
                                            

                                            
                                        </div>
                                    </div>
                                </div>
                            </a>



                            
                                
                                    
                                   
                                       
                                       
                                   

                                
                            

                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>