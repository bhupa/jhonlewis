<?php $__env->startSection('title','Cart Details'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- breadcrumb-->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li aria-current="page" class="breadcrumb-item active">Shopping cart</li>
                            </ol>
                        </nav>
                    </div>
                    <div id="basket" class="col-lg-12">
                        <div class="box">
                            <form method="post" action="checkout1.html">
                                <h1>Shopping cart</h1>
                                <p class="text-muted">You currently have <?php echo e($carts->totalItem); ?> item(s) in your cart.</p>
                                <?php if($message = Session::get('cart-message')): ?>
                                    <div class="alert alert-info alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('flaserror')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session()->get('flaserror')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <div class="cartlist">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th colspan="2">Product</th>
                                            <th>Color</th>
                                            <th>Quantity</th>
                                            <th>Unit price</th>
                                            <th>Discount</th>
                                            <th>Discount Price</th>
                                            <th colspan="2">Total</th>
                                        </tr>
                                        </thead>

                                        <?php if(!empty(Session::get('cart'))): ?>
                                            <tbody>
                                            <?php $i=1; ?>
                                            <?php $__currentLoopData = $carts->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('product.show',[$cart['slug']])); ?>">
                                                    <img src="<?php echo e(asset('storage/'.$cart['image'])); ?>" alt="<?php echo e($cart['title']); ?>">
                                                </a>
                                            </td>

                                            <td><a href="<?php echo e(route('product.show',[$cart['slug']])); ?>"><?php echo e($cart['title']); ?></a></td>
                                            <td><?php echo e($cart['color']); ?></td>
                                            <td>
                                                <div class="cart-increment-btn">
                                                    <input type="hidden" name="id" id="stock-piece" value="">
                                                    <button type="button" id="cart-add" class="cart-altera altera acrescimo" data-quantity="<?php echo e($cart['total_quantity']); ?>" data-quantity="<?php echo e($cart['piece']); ?>" data-type="<?php echo e($cart['stockId']); ?>" data-value="<?php echo e($cart['piece']); ?>"><i class="fa fa-plus"></i></button>
                                                    <input type="number"  name="piece" id="cart-altera-input-<?php echo e($cart['stockId']); ?>" min="1" placeholder="0" class="cart-increment-value" data-quantity="<?php echo e($cart['piece']); ?>" data-type="<?php echo e($cart['stockId']); ?>"  class="cart-increment-value"  value="<?php echo e($cart['piece']); ?>">
                                                    <button type="button" id="cart-sub" class="cart-altera altera decrescimo" data-quantity="<?php echo e($cart['total_quantity']); ?>" data-quantity="<?php echo e($cart['piece']); ?>" data-type="<?php echo e($cart['stockId']); ?>" data-value="<?php echo e($cart['piece']); ?>"><i class="fa fa-minus"></i></button>
                                                    <?php if($errors->has('piece')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('piece')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>

                                            <td>£ <?php echo e($cart['unit_price']); ?></td>
                                            <td><?php echo e($cart['discount']); ?></td>
                                            <td> <?php if(!empty($cart['discount_price'])): ?>  £<?php echo e($cart['discount_price']); ?> <?php endif; ?></td>
                                            <td>£ <?php echo e($cart['price']); ?></td>

                                            <td><a href="<?php echo e(route('cart.remove',[$key])); ?>"><i class="fa fa-trash-o"></i></a></td>
                                        </tr>

                                            </tbody>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tfoot>
                                            <tr>
                                                <th colspan="2">Total </th>
                                                <th colspan="1"><?php echo e($carts->totalItem); ?></th>
                                                <th colspan="4"><?php echo e($carts->totalPiece); ?></th>
                                                <th colspan="2">£ <?php echo e(number_format((float)$carts->totalPrice, 2, '.', '')); ?></th>

                                            </tr>





                                            </tfoot>
                                        <?php else: ?>

                                            <tr>
                                                <td>Product is not add to cart yet.</td>
                                            </tr>
                                        <?php endif; ?>

                                    </table>
                                    </div>
                                </div>
                                <!-- /.table-responsive-->
                                <div class="box-footer d-flex justify-content-between flex-column flex-lg-row">
                                    <a href="<?php echo e(route('cart.clear')); ?>" class="btn btn-outline-secondary"><i class="fa fa-refresh"></i>Clear Cart</a>
                                    <div class="right">
                                        <?php if(Auth::check()): ?>
                                            <?php if(!empty(Session::get('cart'))): ?>
                                        <a href="<?php echo e(route('order.index')); ?>" class="btn btn-primary">Proceed to checkout <i class="fa fa-chevron-right"></i></a>
                                        <?php endif; ?>
                                        <?php else: ?>
                                            <a href="javascript:void(0)" id="check-out-link" data-type="<?php echo e(route('order.index')); ?>" class="btn btn-primary">Proceed to checkout <i class="fa fa-chevron-right"></i></a>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.box-->
                        <div class="row  products">

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-md-4">
                                        <div class="product-single-item">
                                            <a href="<?php echo e(route('product.show',[$product->slug ])); ?>" class="shop-lists">
                                                <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="<?php echo e($product->title); ?>">

                                            </a>
                                            <p><span class="model text-left">Mod: <?php echo e($product->shape); ?></span>
                                            </p>
                                            <p>
                                                <span class="brand">Brand:<?php echo e($product->brand->name); ?></span></p>
                                        </div>

                                        <!-- /.product            -->
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- /.products-->
                        </div>
                    </div>
                    <!-- /.col-lg-9-->
















                    <!-- /.col-md-3-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#check-out-link').on('click',function(){
                var url = $(this).attr('data-type');
                $('#url').val(url)
                $('#login-modal').modal('show');
            })

            $(document).on('click','.cartlist  #cart-add',function(event){

                $("#overlay-load").fadeIn(300);
                var data = $(this).attr('data-value');
                var stock = $(this).attr('data-quantity');
                var id = $(this).attr('data-type');
                var totalPiece = $(this).attr('data-quantity');


                if (parseInt(data) < parseInt(totalPiece) && parseInt(data) != '') {
                    var quantity = Number(data) + 1;
                    cartupdate(id, quantity,totalPiece);
                }

                    $('#cart-altera-input'+id).css('border','1px solid red');


                event.preventDefault();


            });
            $(document).on('click','.cartlist   #cart-sub',function(event){
                event.stopPropagation();
                var object = $(this);
                $("#overlay-load").fadeIn(300);
                var data = $(this).attr('data-value');
                var stock = $(this).attr('data-quantity');
                var id = $(this).attr('data-type');
                var totalPiece = $(this).attr('data-quantity');
                var url = baseUrl+"/cart/add/";
                if (parseInt(data) <= parseInt(totalPiece) && parseInt(data) != '') {
                    var quantity =Number(data)-1;
                    cartupdate(id,quantity, totalPiece);
                }else{
                    $(object).parent('.cart-increment-btn').find('#cart-altera-input').css('border','1px solid red');
                }

                event.preventDefault();

            });
            function cartupdate(id,quantity, totalPiece){
                $.ajax({
                    type:'Post',
                    url:baseUrl+"/cart/add/",
                    data:{stock_id:id,piece:quantity,id: totalPiece},
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType: 'html',
                    success: function (carts) {
                        $('.cartlist').html(carts);
                        setTimeout(function(){
                            $("#overlay-load").fadeOut(300);
                        },500);
                        // $('#cart-success').modal('show');
                    }
                });
            }


        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>