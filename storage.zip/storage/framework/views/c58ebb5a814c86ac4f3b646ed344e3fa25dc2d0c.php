
    <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                <th>No.</th>
                <th colspan="2">Product</th>
                <th>Color</th>
                <th>Quantity</th>
                
                <th colspan="2">Total</th>
            </tr>
            </thead>

            <?php if(!empty(Session::get('cart'))): ?>
                <tbody>
                <?php $i=1; $totalAmout=0; $totalquantity=0;?>
                <?php $__currentLoopData = $carts->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td>
                            <a href="#">
                                <img src="<?php echo e(asset('storage/'.$cart['image'])); ?>" alt="<?php echo e($cart['title']); ?>">
                            </a>
                        </td>

                        <td><a href="<?php echo e(route('product.show',[$cart['slug']])); ?>"><?php echo e($cart['title']); ?></a></td>
                        <td><?php echo e($cart['color']); ?></td>
                        <td>
                            <div class="cart-increment-btn">
                                <?php echo e($cart['piece']); ?>

                            </div>
                        </td>

                        
                        <td>£ <?php echo e($cart['price']); ?></td>
                        <?php $totalAmout +=  $cart['price'] ?>
                        <?php $totalquantity +=  $cart['piece'] ?>

                    </tr>

                </tbody>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tfoot>

                <tr>
                    <th colspan="5">Total Items</th>
                    <th colspan="2"><?php echo e($carts->totalItem); ?></th>

                </tr>
                <tr>
                    <th colspan="5">Total Piece</th>
                    <th colspan="2"><?php echo e($totalquantity); ?></th>

                </tr>
                <tr>
                    <th colspan="5">Shipping Charge</th>
                    <th colspan="2">
                        <span class="shipping-charge">
                            <?php if($shipping =='uk'): ?>
                                Free
                                <?php elseif($shipping =='europe'): ?>
                                £ 7.50
                                <?php else: ?>
                                £ 25
                            <?php endif; ?>
                        </span>
                    </th>

                </tr>
                <tr>
                    <th colspan="5">Total Price</th>
                    <th colspan="2">
                        <?php if($shipping =='uk'): ?>

                        <?php elseif($shipping =='europe'): ?>
                            £ <?php echo e(number_format((float)$totalAmout, 2, '.', '') + 7.50); ?>

                        <?php else: ?>
                            £ <?php echo e(number_format((float)$totalAmout, 2, '.', '') + 25); ?>

                        <?php endif; ?>
                        </th>

                </tr>
                </tfoot>
            <?php else: ?>

                <tr>
                    <td>Product is not add to cart yet.</td>
                </tr>
            <?php endif; ?>

        </table>

    </div>

    <!-- /.table-responsive -->

<!-- /.content -->

    <div class="box-footer d-flex justify-content-between"><a href="javascript:void(0)" class="btn btn-outline-secondary back-payment">Back to Payment</a>
        <?php echo Form::open(['route'=>'paypal.store','method'=>'post']); ?>

        <?php if($shipping =='uk'): ?>
            <input type="hidden" name="amount"  value="<?php echo e(number_format((float)$totalAmout, 2, '.', '')); ?>">
            <input type="hidden" name="shipping" value="0" >

        <?php elseif($shipping =='europe'): ?>
            <input type="hidden" name="shipping" value="7.50" >

            <input type="hidden" name="amount"  value="<?php echo e(number_format((float)$totalAmout, 2, '.', '') + 7.50); ?>">
        <?php else: ?>
            <input type="hidden" name="shipping" value="25" >

            <input type="hidden" name="amount"  value="<?php echo e(number_format((float)$totalAmout, 2, '.', '') + 25); ?>">
            <?php endif; ?>
        <input type="hidden" name="<?php echo e($totalquantity); ?>">
        <button type="submit" id="shipping-delivery-form" class="btn btn-primary">Place Order<i class="fa fa-chevron-right"></i></button>
        <?php echo Form::close();; ?>

    </div>

