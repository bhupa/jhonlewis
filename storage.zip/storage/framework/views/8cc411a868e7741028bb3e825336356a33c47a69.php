<?php $__env->startSection('title','Appointment'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="all">
    <div id="content">
        <div class="container">
            <div class="row">


                    <div class="appointment-form" style="margin-top: 50px;">
                            <div class="appointment-title">
                                <h2>REQUEST AN APPOINTMENT</h2>
                                <?php if(\Session::has('success')): ?>
                                    <div class="alert alert-success">

                                        <span><?php echo \Session::get('success'); ?></span>

                                    </div>

                                <?php endif; ?>
                            </div>
                        <div class="fl-module-content fl-node-content">
                            <div class="pp-infolist-wrap">
                                <div class="pp-infolist layout-3">
                                    <ul class="layout-3-wrapper"> 					<li class="pp-list-item pp-list-item">
                                            <div class="pp-icon-wrapper animated none">
                                                <div class="pp-infolist-icon">
                                                    <div class="pp-infolist-icon-inner">
                                                        <span class="pp-icon "></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pp-infolist-title">
                                                <h3 class="pp-infolist-title-text child-line">1</h3>
                                            </div>
                                            <div class="pp-infolist-description">
                                            </div>
                                            <div class="pp-list-connector" ></div>
                                        </li> 					<li class="pp-list-item pp-list-item">
                                            <div class="pp-icon-wrapper animated none">
                                                <div class="pp-infolist-icon">
                                                    <div class="pp-infolist-icon-inner">
                                                        <span class="pp-icon "></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pp-infolist-title">
                                                <h3 class="pp-infolist-title-text child-line">2</h3>
                                            </div>
                                            <div class="pp-infolist-description">
                                            </div>
                                            <div class="pp-list-connector" ></div>
                                        </li> 					<li class="pp-list-item pp-list-item">
                                            <div class="pp-icon-wrapper animated none">
                                                <div class="pp-infolist-icon">
                                                    <div class="pp-infolist-icon-inner">
                                                        <span class="pp-icon "></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pp-infolist-title">
                                                <h3 class="pp-infolist-title-text">3</h3>
                                            </div>
                                            <div class="pp-infolist-description">
                                            </div>
                                            <div class="pp-list-connector" ></div>
                                        </li> 		</ul>
                                </div>
                            </div>
                        </div>
                        <div class="appointment-form">
                            <?php echo Form::open(['route'=>'appointment.store','method'=>'Post']); ?>

                            <div class="row">
                                <div class="col-lg-4 contact-details1">
                                    <h4><span>Contact Details</span></h4>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <select name="gender" class="form-control" aria-required="true" aria-invalid="false">
                                                    <option value="">Title*</option>
                                                    <option value="Mr." <?php echo e((old('gender')== 'Mr.')? 'selected':''); ?>>Mr.</option>
                                                    <option value="Mrs." <?php echo e((old('gender')== 'Mrs.')? 'selected':''); ?>>Mrs.</option>
                                                    <option value="Miss" <?php echo e((old('gender')== 'Miss')? 'selected':''); ?>>Miss</option>
                                                    <option value="Others" <?php echo e((old('gender')== 'Others')? 'selected':''); ?>>Others</option>
                                                </select>
                                                <?php if($errors->has('gender')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-lg-8">
                                                <input type="text" class="form-control" name="firstname" placeholder="First name*"  value="<?php echo e(old('firstname')); ?>">
                                                <?php if($errors->has('firstname')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('firstname')); ?></span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="lastname" placeholder="Surname*" value="<?php echo e(old('lastname')); ?>">
                                        <?php if($errors->has('lastname')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('lastname')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="number" class="form-control" name="phone" placeholder="Phone number*" value="<?php echo e(old('phone')); ?>">
                                        <?php if($errors->has('phone')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" placeholder="Email*" value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                                <div class="col-lg-4 contact-details1">
                                    <h4><span>Preferred Appointment</span></h4>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <input type="text" name="date" class="form-control datepicker" placeholder="Select date *" autocomplete="off" value="<?php echo e(old('date')); ?>">
                                                <?php if($errors->has('date')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-lg-6">
                                                
                                                <select name="time" class="form-control" aria-required="true" aria-invalid="false">
                                                    <option value="">Select Time*</option>
                                                    <option value="Early Morning"<?php echo e((old('time')== 'Early Morning')? 'selected':''); ?>>Early Morning</option>
                                                    <option value="Late Morning"<?php echo e((old('time')== 'Late Morning')? 'selected':''); ?>>Late Morning</option>
                                                    <option value="Early Afternoon"<?php echo e((old('time')== 'Early Afternoon')? 'selected':''); ?>>Early Afternoon</option>
                                                    <option value="Late Afternoon"<?php echo e((old('time')== 'Late Afternoon')? 'selected':''); ?>>Late Afternoon</option>
                                                </select>
                                                <?php if($errors->has('time')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('time')); ?></span>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>

                                    <h4 class="appo-details">Appointment Details</h4>

                                    <span class="list-item first">
                                        <input type="radio" name="details" <?php echo e((old('details')== 'Eye Examination')? 'checked':''); ?>  value="Eye Examination"><span class="list-item-label">Eye Examination
                                        </span>
                                    </span>
                                    <span class="list-item ">
                                        <input type="radio" name="details" <?php echo e((old('details')== 'Contact Lens Aftercare')? 'checked':''); ?>  value="Contact Lens Aftercare"><span class="list-item-label">Contact Lens Aftercare
                                        </span>
                                    </span>
                                    <span class="list-item ">
                                        <input type="radio" name="details" <?php echo e((old('details')== 'Contact Lens Fitting')? 'checked':''); ?>  value="Contact Lens Fitting"><span class="list-item-label">Contact Lens Fitting
                                        </span>
                                    </span>
                                    <span class="list-item ">
                                        <input type="radio" name="details" <?php echo e((old('details')== 'Frame Consultation')? 'checked':''); ?>  value="Frame Consultation"><span class="list-item-label">Frame Consultation
                                        </span>
                                    </span>
                                    <span class="list-item ">
                                        <input type="radio" name="details" <?php echo e((old('details')== 'Others')? 'checked':''); ?>  value="Others"><span class="list-item-label">Others
                                        </span>
                                    </span><br>
                                    <?php if($errors->has('details')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('details')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-4 contact-details1">
                                    <h4>
                                        <span></span></h4>

                                    <p>Request your appointment and a member of the team will call you back.</p>

                                    <div class="submit-btn">
                                        <button type="submit" value="REQUEST AN APPOINTMENT">REQUEST AN APPOINTMENT</button>
                                    </div>

                                    <p>If you need any help please call us</p><br>

                                    <span class="phone-number text-center">02083161121</span>
                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>


                    </div>

                







                    


                            
                        

                    

                    
                
                
                
                    
                        
                            
                        
                        
                            
                                
                                    
                                

                                
                                    
                                    
                                        
                                    

                                    
                                        
                                         
                                    
                                    
                                        
                                         
                                    
                                
                            
                        
                            


                    
                    
                </div>
                <!-- /.col-lg-3-->

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#appointment-url').on('click', function () {
                var url = $(this).attr('data-type');
                $('#url').val(url)
                $('#login-modal').modal('show');
            })

        });
        $(function() {
            var active_dates = '<?php echo e(json_encode($scheduls)); ?>';
            var vardata = JSON.parse(active_dates.replace(/&quot;/g,'"'));
            $('.datepicker').datepicker({
                format: "dd-mm-yyyy",
                todayHighlight: true,
                startDate: new Date(),
                beforeShowDay: function(date){
                    var d = date;
                    var curr_date = d.getDate();
                    var curr_month = ("0" + (d.getMonth() + 1)).slice(-2);
                    var curr_year = d.getFullYear();
                    var formattedDate = curr_date + "-" + curr_month + "-" + curr_year

                    if (date.getDay() == 4){
                        return {
                            classes: 'activeClass'
                        };
                    }
                    else{
                        return false;
                    }
                    return;
                }
            });
        });




        // function displayMessage(message) {
        //     $(".response").html("
        //     "+message+"
        //     ");
        //     setInterval(function() { $(".success").fadeOut(); }, 1000);
        // }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
    </script>
    <?php echo $calendar->script(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>