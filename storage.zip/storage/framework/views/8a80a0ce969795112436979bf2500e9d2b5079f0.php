
<li class="nav-item dropdown ">
    <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="true">
        <i class="far fa-bell"></i>
        <span class="badge badge-warning navbar-badge"><?php echo e($totals); ?></span>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right ">
        <span class="dropdown-item dropdown-header"><?php echo e($totals); ?> Notifications</span>
        <div class="dropdown-divider"></div>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="dropdown-divider"></div>
            <a href="<?php echo e($notification->link); ?>" class="dropdown-item">
                <i class="fa fa-plus mr-2"></i><?php echo e($notification->order->total_item); ?>  has been ordered
                <span class="float-right text-muted text-sm"><?php echo e(Carbon\Carbon::parse($notification->created_at)->diffForHumans()); ?> </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






        <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
    </div>
</li>
<li class="nav-item">
    <a class="nav-link"  href="<?php echo e(route('logout')); ?>"><i class="fas fa-lock"></i></a>
</li>
