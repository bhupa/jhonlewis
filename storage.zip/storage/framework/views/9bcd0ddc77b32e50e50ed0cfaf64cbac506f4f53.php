<?php $__env->startSection('title','Blog'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    
                        
                        
                            
                                
                                
                            
                        
                    
                    <div id="checkout" class="col-lg-12">

                        <div id="blog-homepage" class="row" style="margin-top: 50px;">
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-6">
                                    <div class="post">
                                        <h4><a href="<?php echo e(route('blog.show',[$blog->slug])); ?>"><?php echo e($blog->title); ?></a></h4>
                                        <p class="author-category">By <a href="<?php echo e(route('blog.show',[$blog->slug])); ?>"><?php echo e($blog->author->name); ?></a> Category <a href="<?php echo e(route('blog.show',[$blog->slug])); ?>"><?php echo e($blog->category->name); ?></a></p>
                                        <hr>
                                        <p class="intro">
                                            <?php echo e(str_limit($blog->short_description,'200','....')); ?>

                                        </p>
                                        <p class="read-more"><a href="<?php echo e(route('blog.show',[$blog->slug])); ?>" class="btn btn-primary">Continue reading</a></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- /.box-->
                        <div class="pages">
                            <nav aria-label="Page navigation example" class="d-flex justify-content-center">
                                <nav aria-label="Page navigation example" class="d-flex justify-content-center">
                                    <?php echo e($blogs->links('vendor.pagination.default')); ?>

                                </nav>
                            </nav>
                        </div>
                    </div>
                    <!-- /.col-lg-9-->

                </div>
                <!-- /.col-lg-3-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>