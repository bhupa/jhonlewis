<?php $__env->startSection('title', $content->title); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    
                        
                        
                            
                                
                                
                            
                        
                    

                    <?php if($content->slug =='frame-brand'): ?>
                        <div class="service-lists-content">
                            <h4><?php echo e($content->title); ?></h4>
                            <hr>
                            <div class="row" id="frames-brand">
                                <div class="col-md-6 col-lg-6">
                                    <div class="frame-wrapper-title">
                                        <img src="<?php echo e(asset('frontend/img/brand-frame.png')); ?>" alt="frame-brand" style="width: 100%;height:300px">
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6">
                                    <div class="frame-wrapper">
                                        <?php echo $content->description; ?>

                                    </div>
                                </div>
                            </div>

                            <ul class="product-type-lists">
                                <li>
                                    <div class="top-level">
                                        <a href="javascript:void(0)" data-toggle="collapse" data-target="#eye-care">Eye Wear
                                            <span class="close"></span>
                                        </a>


                                    </div>

                                    <div id="eye-care" class="collapse show frame-brand-lists">
                                        <div class="row">
                                            <?php $__currentLoopData = $eyecares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $care): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-6 col-lg-4">
                                                    <div class="product-lists">
                                                        <a href="">
                                                            <div class="new"></div>
                                                            <img src="<?php echo e(asset('storage/'.$care->image)); ?>" alt="<?php echo e($care->title); ?>">

                                                            
                                                            
                                                            
                                                            
                                                                
                                                            
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                    </div>
                                </li>
                                <li>
                                    <div class="top-level">
                                        <a href="javascript:void(0)" data-toggle="collapse" data-target="#kid-care">Kid Wear
                                            <span class="close"></span>
                                        </a>


                                    </div>

                                    <div id="kid-care" class="collapse frame-brand-lists">
                                        <div class="row">
                                            <?php $__currentLoopData = $kidwears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ware): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4">
                                                    <div class="product-lists">
                                                        <a href="">
                                                            <div class="new"></div>
                                                            <img src="<?php echo e(asset('storage/'.$ware->image)); ?>" alt="<?php echo e($ware->title); ?>">

                                                            
                                                            
                                                            
                                                            
                                                                
                                                            
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                    </div>
                                </li>
                                <li>
                                    <div class="top-level">
                                        <a href="javascript:void(0)" data-toggle="collapse" data-target="#sunglass">Sunglass
                                            <span class="close"></span>
                                        </a>


                                    </div>

                                    <div id="sunglass" class="collapse frame-brand-lists">
                                        <div class="row">
                                            <?php $__currentLoopData = $sunglasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $glass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4">
                                                    <div class="product-lists">
                                                        <a href="">
                                                            <div class="new"></div>
                                                            <img src="<?php echo e(asset('storage/'.$glass->image)); ?>" alt="<?php echo e($glass->title); ?>">

                                                            
                                                            
                                                            
                                                            
                                                                
                                                            
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                    </div>
                                </li>

                            </ul>



                        </div>
                    <?php else: ?>
                        
                                
                        
                        <div class="col-lg-12">

                            <div class="service-lists-content">
                                <h4><?php echo e($content->title); ?></h4>
                                <hr>
                                <?php if(file_exists('storage/'.$content->image) && $content->image != ''): ?>
                                <img src="<?php echo e(asset('storage/'.$content->image)); ?>" alt="<?php echo e($content->title); ?>">
                                <?php endif; ?>
                                    <?php echo $content->description; ?>


                            </div>

                    </div>
                    <?php endif; ?>
                </div>
                <!-- /.col-md-9-->

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#check-out-link').on('click',function(){
                var url = $(this).attr('data-type');
                $('#url').val(url)
                $('#login-modal').modal('show');
            })

            $(document).on('click','.cartlist  #cart-add',function(event){

                $("#overlay-load").fadeIn(300);
                var data = $(this).attr('data-value');
                var stock = $(this).attr('data-quantity');
                var id = $(this).attr('data-type');
                var totalPiece = $(this).attr('data-quantity');


                if (parseInt(data) < parseInt(totalPiece) && parseInt(data) != '') {
                    var quantity = Number(data) + 1;
                    cartupdate(id, quantity,totalPiece);
                }

                $('#cart-altera-input'+id).css('border','1px solid red');


                event.preventDefault();


            });
            $(document).on('click','.cartlist   #cart-sub',function(event){
                event.stopPropagation();
                var object = $(this);
                $("#overlay-load").fadeIn(300);
                var data = $(this).attr('data-value');
                var stock = $(this).attr('data-quantity');
                var id = $(this).attr('data-type');
                var totalPiece = $(this).attr('data-quantity');
                var url = baseUrl+"/cart/add/";
                if (parseInt(data) <= parseInt(totalPiece) && parseInt(data) != '') {
                    var quantity =Number(data)-1;
                    cartupdate(id,quantity, totalPiece);
                }else{
                    $(object).parent('.cart-increment-btn').find('#cart-altera-input').css('border','1px solid red');
                }

                event.preventDefault();

            });
            function cartupdate(id,quantity, totalPiece){
                $.ajax({
                    type:'Post',
                    url:baseUrl+"/cart/add/",
                    data:{stock_id:id,piece:quantity,id: totalPiece},
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType: 'html',
                    success: function (carts) {
                        $('.cartlist').html(carts);
                        setTimeout(function(){
                            $("#overlay-load").fadeOut(300);
                        },500);
                        // $('#cart-success').modal('show');
                    }
                });
            }


        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>