<?php $__env->startSection('title','Profile-Setting'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- breadcrumb-->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li aria-current="page" class="breadcrumb-item active">Setting</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-lg-3">

                        <?php echo $__env->make('profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div id="customer-order" class="col-lg-9">
                        <div class="box">
                            <h1>My account</h1>
                            <p class="lead">Change your personal details or your password here.</p>

                            <h3>Change password</h3>
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <ul>
                                        <li><?php echo \Session::get('success'); ?></li>
                                    </ul>
                                </div>

                            <?php endif; ?>
                            <?php echo e(Form::open(['route'=>'login.store'])); ?>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="password_old">Old password</label>
                                            <input type="password" name="old_password" class="form-control" id="password_old">
                                            <?php if($errors->has('old_password')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('old_password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="password_1">New password</label>
                                            <input type="password" name="new_password" class="form-control" id="password_1">
                                            <?php if($errors->has('new_password')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="password_2">Retype new password</label>
                                            <input type="password" name="confirm" class="form-control" id="password_2">
                                            <?php if($errors->has('confirm')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('confirm')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.row -->

                                <div class="col-sm-12 text-center">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save new password</button>
                                </div>
                            <?php echo Form::close(); ?>


                            <hr>

                            <h3>Personal details</h3>
                            <?php echo e(Form::open(['route'=>'profile.store','enctype'=>   "multipart/form-data"])); ?>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="firstname">Firstname</label>
                                            <input type="text"  name="first_name" class="form-control" id="firstname" value="<?php echo e($user->first_name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="lastname">Lastname</label>
                                            <input type="text"  name="last_name" class="form-control" id="lastname" value="<?php echo e($user->last_name); ?>">
                                        </div>
                                    </div>
                                </div>
                                <!-- /.row -->

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="company">User Name</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="street">Address</label>
                                            <input type="text" name="address" class="form-control" id="street" value="<?php echo e($user->address); ?>">
                                        </div>
                                    </div>
                                </div>
                                <!-- /.row -->

                                <div class="row">
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="city">Country</label>
                                            <input type="text" name="country" class="form-control" id="country" value="<?php echo e($user->country); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="zip">State</label>
                                            <input type="text" name="state" class="form-control" id="state" value="<?php echo e($user->state); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="zip">ZIP-Code</label>
                                            <input type="text" name="zip_code" class="form-control" id="zip" value="<?php echo e($user->zip_code); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="zip">Postal-Code</label>
                                            <input type="text" name="postal_code" class="form-control" id="zip" value="<?php echo e($user->postal_code); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="state">Contact</label>
                                            <input type="text" name="contact" class="form-control" id="contact" value="<?php echo e($user->contact); ?>">
                                        </div>
                                    </div>


                                    <div class="col-sm-6 col-md-3">
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="text" class="form-control" id="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="phone">Image</label>
                                            <div class="yes">
    <span class="btn_upload">
      <input type="file" name="image"  id="imag4" title="" />
      Choose Image
      </span>
                                                <?php if(file_exists('storage/'.$user->image) && $user->image != ''): ?>
                                                    <img id="ImgPreview4" src="<?php echo e(asset('storage/'.$user->image)); ?>" class="preview4 it" alt="<?php echo e($user->name); ?>"/>
                                                    <a href="" class="btn-rmv4" id="removeImage4">x</a>
                                                <?php else: ?>
                                                    <img id="ImgPreview4" src="<?php echo e(asset('backend/dist/img/placeholder.png')); ?>" class="preview4 it" />
                                                    
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 text-center">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save changes</button>

                                    </div>
                                </div>
                         <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script>
        $(document).ready( function () {
            function readURL(input, imgControlName) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(imgControlName).attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
            $("#imag4").change(function() {
                // add your logic to decide which image control you'll use
                var imgControlName = "#ImgPreview4";
                readURL(this, imgControlName);
                $('.preview4').addClass('it');
                $('.btn-rmv4').addClass('rmv');
            });
            $("#removeImage4").click(function(e) {
                e.preventDefault();
                $("#imag4").val("");
                $("#ImgPreview4").attr("src", "");
                $('.preview4').removeClass('it');
                $('.btn-rmv4').removeClass('rmv');
            });
        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>