<?php $__env->startSection('title',$product->title); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    
                        
                        
                            
                                
                                
                                
                                    
                                
                            
                        
                    
                    <div class="col-lg-4 order-2 order-lg-1">
                        <?php echo $__env->make('product.lists', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <div class="col-lg-8 order-1 order-lg-2">
                        <div id="productMain" class="row" style="margin-top: 50px">
                            <div class="col-md-6">
                                <div data-slider-id="1" class="product-details-wrapper">

                                   <div class="product-wrapper-content">
                                       <div class="product-image-wrapper">
                                           <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="<?php echo e($product->title); ?>" class="img-fluid">
                                       </div>
                                       <div class="product-wrapper-content">
                                           <ul id="prodcut-details-lists-frontend">

                                               <li><span>Brand:</span><?php echo e($product->brand->name); ?></li>
                                               <li><span>Size:</span><?php echo e($product->size); ?></li>
                                               <li><span>Model:</span><?php echo e($product->shape); ?></li>
                                                       <?php if(!empty($product->disocunt_id)): ?>
                                               <li><span>Style:</span><?php echo e($product->discount->percentage); ?></li>
                                                       <?php endif; ?>
                                               <li><span>Warranty:</span>
                                                   <?php if(!empty($product->warranty)): ?>
                                                       <?php echo e($product->warranty); ?>

                                                   <?php else: ?>
                                                       No
                                                   <?php endif; ?>
                                               </li>
                                           </ul>

                                       </div>
                                   </div>
                                </div>
                                <?php if(!empty($product->discount_id)): ?>
                                    <div class="ribbon sale discount-tage">
                                        <div class="theribbon" style="width: 162px;">off <?php echo e($product->discount->percentage); ?>%</div>
                                        <div class="ribbon-background"></div>
                                    </div>
                            <?php endif; ?>
                                <!-- /.ribbon-->
                                <div class="ribbon new">
                                    <div class="theribbon">NEW</div>
                                    <div class="ribbon-background"></div>
                                </div>
                                <!-- /.ribbon-->
                            </div>
                            <div class="col-md-6">
                                <div class="box">
                                    <h1 class="text-center"><?php echo e($product->title); ?></h1>
                                    <p class="goToDescription"><a href="#details" class="scroll-to">Scroll to product details, material &amp; care and sizing</a></p>

                                    <?php if(!empty($product->discount_id)): ?>
                                        <p class="price">
                                            <strike>£<?php echo e($product->price); ?></strike><br>
                                            <?php $discount = $product->price - ($product->price * ($product->discount->percentage / 100))?>
                                            £ &nbsp;<?php echo e($discount); ?>

                                        </p>
                                    <?php else: ?>
                                        <p class="price">
                                            <del></del>£&nbsp;<?php echo e($product->price); ?>

                                        </p>
                                    <?php endif; ?>
                                    <?php if($product->stocks->isNotEmpty()): ?>
                                    <?php echo Form::open(['route'=>'cart.store','method'=>'post','id'=>'add-cart']); ?>


                                    <div class="row">
                                        <?php if(\Session::has('success')): ?>
                                            <div class="alert alert-success">
                                                <span><?php echo \Session::get('success'); ?></span>
                                            </div>

                                        <?php endif; ?>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="firstname">Select Color</label>
                                                <select name="stock_id" id="stock" class="form-control">
                                                    <option value="0"> Choose from stock</option>
                                                    <?php $__currentLoopData = $product->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($stock->id); ?>" data-type="<?php echo e($stock->piece); ?>"><?php echo e($stock->color->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('stock_id')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('stock_id')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="lastname">Total Quantity : <span id="stock-quantity"></span></label>
                                                <div class="cart-increment-btn">
                                                    <input type="hidden" name="id" id="stock-piece" value="">
                                                    <button type="button" class="altera acrescimo"><i class="fa fa-plus"></i></button>
                                                    <input type="number"  name="piece" id="stepper-input" min="1" placeholder="0" class="cart-increment-value"  value="1">
                                                    <button type="button" class="altera decrescimo"><i class="fa fa-minus"></i></button>
                                                    <?php if($errors->has('piece')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('piece')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <p class="text-center buttons">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-shopping-cart">
                                        </i> Add to cart
                                    </button>
                                        <?php if(Auth::check()): ?>
                                        <a id="add-whishlist" data-type="<?php echo e($product->id); ?>" href="javascript:void(0)" class="btn btn-success"><i class="fa fa-heart"></i> Add to wishlist</a>
                                        <?php endif; ?>

                                    </p>
                                    <?php echo e(Form::hidden('product_id',$product->id)); ?>

                                    <?php echo e(Form::close()); ?>

                                       <?php else: ?>
                                        <span>Not in Stock</span>
                                        <?php endif; ?>
                                </div>









                            </div>
                        </div>
                        
                            
                            
                           
                               
                           
                            
                                
                                
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                        
                                    
                                
                                
                            
                        
                    </div>
                    <!-- /.col-md-9-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript">
        $('document').ready(function(){
           $('#stock').on('change',function(){
               var quantity = $('#stock option:selected').attr('data-type');
               $('#stock-quantity').text(quantity);
               $('#stock-piece').val(quantity);
           })
            current = 1;
            $('#add-cart ').on('click','.altera',function(event) {

                event.stopImmediatePropagation();

                var quantity =  $('#stock-piece').val();
                var data =  $('#stepper-input').val();


                if (data < parseInt(quantity)) {

                    if ($(this).hasClass('acrescimo')) {
                        var value =Number(data)+1;
                        $('.cart-increment-value').val(value);
                        $('#cart-submit').removeAttr("disabled");
                        $('.decrescimo').removeAttr("disabled");
                        $('.cart-increment-value').css('border','1px solid black');


                    }
                }
                if (data > 0){
                    if ($(this).hasClass('decrescimo')) {
                        if(data >1){
                            var value =Number(data)-1;
                            $('.cart-increment-value').val(value);
                        }else{
                            alert('Select the piece is lower than default value ');
                            $('.cart-increment-value').css('border','1px solid red');
                            $('.decrescimo').prop("disabled", true);
                        }


                    }
                }

            });
            $(window).on('load', function() {
                var quantity = $('#stock option:selected').attr('data-type');
                $('#stock-quantity').text(quantity);
                $('#stock-piece').val(quantity);
            })

            $('#add-whishlist').on('click',function(){
                var id = $(this).attr('data-type');
                $('.show-box').css('display','block');


                $.ajax({
                    type:'Post',
                    url:'<?php echo e(route('wishlist.store')); ?>',
                    data:{id:id},
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType: 'json',
                    success: function (carts) {
                        setTimeout(function(){
                            $(".show-box").fadeOut(3000);
                        },3000);
                        // $('#cart-success').modal('show');
                    },
                    errors:function(xhr){

                        setTimeout(function(){
                            $(".show-box").fadeOut(3000);
                            $("#error-modal").modal('show');

                        },5000);
                    }
                });
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>