<div class="row">
    <div class="col-sm-6">
        <div class="box payment-method">

            <h4>Paypal</h4>

            <p>We like it all.</p>

            <div class="box-footer text-center">

                <input type="radio" name="payment" checked value="payment1">
            </div>
        </div>
    </div>

</div>
<div class="box-footer d-flex justify-content-between"><a href="javascript:void(0)" class="btn btn-outline-secondary back-to-shipping">Back to Delivery</a>
    <button type="submit" id="shipping-order-review" class="btn btn-primary">Continue to order review<i class="fa fa-chevron-right"></i></button>
</div>
