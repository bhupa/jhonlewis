<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="all">
    <div id="content">
        
            <div class="row">
                <div class="col-md-12">
                    <div id="main-slider" class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="banner-wrapper">
                                <img src="<?php echo e(asset('storage/'.$banner->image)); ?>" alt="<?php echo e($banner->title); ?>" class="img-fluid">
                                <div class="banner-content">
                                    
                                        
                                        
                                            
                                        
                                    
                                </div>


                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /#main-slider-->
                </div>
            </div>
        
    </div>
        <!--
        *** ADVANTAGES HOMEPAGE ***
        _________________________________________________________
        -->
            <div id="home-content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            
                            <div class="home-wrapper">
                                <div class="home-image">

                                    <?php if(!empty($home->slug)): ?>
                                        <?php if(file_exists('storage/'.$home->image) && $home->image != ''): ?>
                                            <img src="<?php echo e(asset('storage/'.$home->image)); ?>" alt="<?php echo e($home->title); ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="home-wrapper">
                                <div class="home-wrapper-content">
                                    <div class="title">
                                        <h1>John Lewis Opticians</h1>
                                    </div>

                                    <div class="home-paragraph">
                                      <p>  <?php echo $home->description; ?>

                                        </p>
                                    </div>


                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>

            </div>
        
            
                
                    
                        
                            
                        
                    
                
            
            
                
                    
                    
                        
                            
                                
                            
                            
                            
                            
                        
                    
                    
                

                
            
            
        
        <!-- /#advantages-->
        <!-- *** ADVANTAGES END ***-->
        <!--
        *** HOT PRODUCT SLIDESHOW ***
        _________________________________________________________
        -->

        <div id="hot">
            
                
                    
                        
                            
                        
                    
                
            
            <div class="container">
                <div class="contact-lens pb-5 pt-5">
                    <div class="row">
                        <?php if(!empty($about->slug)): ?>

                        <div class="col-lg-6">
                            <div class="contact-lens-content">
                                <h2 class="heading-title"><?php echo e($about->title); ?></h2>
                                <div class="contact-lens-content-wrapper">
                                    <?php echo $about->short_description; ?>

                                </div>

                            </div>

                            <div class="contact-lens-btn">
                                <a href="<?php echo e(route('content.show',['about-us'])); ?>" class="btn btn-about-us">
                                    More Info
                                </a>
                            </div>
                        </div>
                            <div class="col-lg-6">
                                <div class="contact-lens-image-wrapper">
                                    <?php if(file_exists('storage/'.$about->image) && $about->image != ''): ?>
                                        <img src="<?php echo e(asset('storage/'.$about->image)); ?>" alt="<?php echo e($about->title); ?>">
                                    <?php endif; ?>

                                </div>
                            </div>
                    </div>

                    <?php endif; ?>
                </div>
                <hr>
                <div class="contact-lens pb-5 pt-5">
                    <div class="row">
                        <?php if(!empty($eyecare->slug)): ?>

                            <div class="col-lg-6">
                                <div class="contact-lens-image-wrapper">
                                    <?php if(file_exists('storage/'.$eyecare->image) && $eyecare->image != ''): ?>
                                        <img src="<?php echo e(asset('storage/'.$eyecare->image)); ?>" alt="<?php echo e($eyecare->title); ?>">
                                    <?php endif; ?>

                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="contact-lens-content">
                                    <h2 class="heading-title"><?php echo e($eyecare->title); ?></h2>
                                    <div class="contact-lens-content-wrapper">
                                        <?php echo $eyecare->short_description; ?>

                                    </div>

                                </div>

                                <div class="contact-lens-btn">
                                    <a href="<?php echo e(route('content.show',['eye-care'])); ?>" class="btn btn-about-us">
                                        More Info
                                    </a>
                                </div>
                            </div>
                    </div>

                    <?php endif; ?>
                </div>

                    <hr>
                <div class="contact-lens pb-5 pt-5">
                    <div class="row">
                        <?php if(!empty($contactlens->slug)): ?>


                            <div class="col-lg-6">
                                <div class="contact-lens-content">
                                    <h2 class="heading-title"><?php echo e($contactlens->title); ?></h2>
                                    <div class="contact-lens-content-wrapper">
                                        <?php echo $contactlens->short_description; ?>

                                    </div>

                                </div>

                                <div class="contact-lens-btn">
                                    <a href="<?php echo e(route('content.show',['contact-lens'])); ?>" class="btn btn-about-us">
                                        More Info
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="contact-lens-image-wrapper">
                                    <?php if(file_exists('storage/'.$contactlens->image) && $contactlens->image != ''): ?>
                                        <img src="<?php echo e(asset('storage/'.$contactlens->image)); ?>" alt="<?php echo e($contactlens->title); ?>">
                                    <?php endif; ?>

                                </div>
                            </div>
                    </div>

                    <?php endif; ?>
                </div>
                <hr>
                <div class="contact-lens pb-5 pt-5">
                    <div class="row">
                        <?php if(!empty($frame->slug)): ?>


                            <div class="col-lg-6">
                                <div class="contact-lens-image-wrapper">
                                    <?php if(file_exists('storage/'.$frame->image) && $frame->image != ''): ?>
                                        <img src="<?php echo e(asset('storage/'.$frame->image)); ?>" alt="<?php echo e($frame->title); ?>">
                                    <?php endif; ?>

                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="contact-lens-content">
                                    <h2 class="heading-title"><?php echo e($frame->title); ?></h2>
                                    <div class="contact-lens-content-wrapper">
                                        <?php echo $frame->short_description; ?>

                                    </div>

                                </div>

                                <div class="contact-lens-btn">
                                    <a href="<?php echo e(route('frame-brands')); ?>" class="btn btn-about-us">
                                        More Info
                                    </a>
                                </div>
                            </div>
                    </div>

                    <?php endif; ?>
                </div>


                
                    
                    
                        
                            
                                
                            

                            
                                
                                
                                    
                                
                                
                            
                        
                    
                    
                    
                
                
            </div>
            <!-- /#hot-->
            <!-- *** HOT END ***-->
        </div>

    <div class="new-subscribe">
        <div class="container">
            <div class="subscribe-form">

                <h3>Subscribe</h3>
                <p>Sign up to get on sales,new release and more.</p>
                <div  id="message-success">
                    <span></span>
                </div>
                    <?php echo Form::open(['route'=>'email-subscribe.store','method'=>'post','id'=>'email-subscribe']); ?>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-6">
                                <lable>First Name</lable>
                                <input type="text" name="firstname" class="form-control" placeholder="Full Name" id="firstname">
                            </div>
                            <div class="col-lg-6">
                                <lable>Last Name</lable>
                                <input type="text" name="lastname" class="form-control" placeholder="Last Name" id="lastname">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-8">
                                <lable>Email</lable>
                                <input type="Email" name="email" class="form-control" placeholder="Enter your email address" id="email">
                            </div>
                            <div class="col-lg-4">
                                <button class="btn btn-submit">SIGN UP</button>
                            </div>
                        </div>
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    
        
            

                

                

                    
                        
                            
                                
                                    

                                    
                                    
                                    
                                        

                                
                            

                            
                        
                

                
                
            
            
        
    </div>
<div class="appointment-section">
    <div class="container">
        <div class="appointment-section-wrapper">

            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('appointment.index')); ?>">Book An Appointment</a>

            <?php else: ?>
                <a href="javascript:void(0)" class="appointment-btn-modal" data-type="<?php echo e(route('appointment.index')); ?>">Book An Appointment</a>

            <?php endif; ?>
        </div>
    </div>
</div>

    
        
            
                

                
            
        
    
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2484.2153447680557!2d0.06920631530132262!3d51.49091561973007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a8c1ceb86f69%3A0x5f31c5de7325f729!2sJohn%20Lewis%20Opticians!5e0!3m2!1sen!2snp!4v1592116587032!5m2!1sen!2snp" width="100%" height="450" frameborder="0" style="border:0; margin-top: 20px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

        
            
                
                    
                        
                            
                        
                    
                
            
            
                
                    
                    
                        
                            
                                
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                        
                                        
                                        
                                    
                                    
                                
                                    
                                
                                    

                            
                            
                            
                            
                                
                                
                            
                            

                            
                                
                                    
                                    
                                        
                                
                                
                            
                            
                            
                                
                                
                            
                            
                        
                        
                    
                    

                    
                
                
            
            
            
        
        
        
        
        

        
            
            
                
                    
                        
                            
                                
                                    
                                
                                
                                    
                                        
                                            
                                        
                                            
                                                
                                                
                                                
                                                    
                                                
                                                

                                                    
                                                    
                                                    
                                                
                                                    
                                                
                                            


                                    
                                
                            
                        
                    
                    
                        
                            
                                
                                    
                                
                                
                            
                        
                    
                
            
        
        
        
        
        
        
            
                
                    

                
            
        
        

            

                
                


                    
                        
                            
                            
                            
                        
                        
                            
                                
                                    
                                    
                                        
                                
                                
                                    
                                    
                                        
                                
                                
                                    
                                    
                                        
                                
                            
                        
                        
                            
                            
                        
                    

                

                

            

        
        
            
                
                    
                
            
        
        
            
                
                    
                    
                        
                            
                            
                            
                            
                                
                            
                            
                        
                    
                    
                
                
            
        
        
        
    
    
        
            
                
                
            
        
    
    
        
            
                
                
                    
                        
                            
                                
                                    
                                
                                    
                                
                            
                            
                                
                                
                                    
                                
                            
                        
                    
                
               


            
        
    

    <!-- /.container-->
    <!-- *** BLOG HOMEPAGE END ***-->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript" >
        jQuery(document).ready(function(){
            $('#email-subscribe').on('submit',function(){
                event.preventDefault();

                var url = '<?php echo e(route('email-subscribe.store')); ?>'
                var data = $( this ).serialize();
                $.ajax({
                    type:'POST',
                    url:url,headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },

                    data:data,
                    dataType: 'json',
                    success:function(data){
                        console.log(data.message)
                        $('#email-subscribe')[0].reset();
                        setTimeout(function(){
                            $('#message-success').addClass('alert alert-success');
                            $('#message-success span').text(data.message);

                        }, 5000);

                    },
                    error: function (xhr,data) {
                        console.log(xhr);
                        $.each(xhr.responseJSON.errors, function (key, value) {
                            $('#' + key).css('border','1px solid rgb(243, 78, 15)');
                            $('#' + key).attr("placeholder", value);

                        });
                    }
                })

            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>