<?php $__env->startSection('title','Service'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    
                        
                        
                            
                                
                                
                            
                        
                    
                    
                        
                            
                                
                                    
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                    
                                
                            

                            
                        
                        
                    


                    <div class="col-lg-4">

                        <div class="service-lists">
                            <h2><?php echo e($content->title); ?></h2>

                            <hr>
                            <ul>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="javascript:void(0)" class="service-lists-btn" data-type="<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                            <a href="<?php echo e(route('service.index')); ?>">Back to Service</a>
                        </div>

                    </div>
                    <div class="col-lg-8">
                        <div class="service-lists-content">
                            <h4>Services</h4>
                            <hr>
                            <img src="<?php echo e(asset('storage/'.$content->image)); ?>" alt="<?php echo e($content->title); ?>">
                            <?php echo $content->description; ?>

                        </div>
                    </div>
                    <!-- /.col-lg-9-->

                </div>
                <!-- /.col-lg-3-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {

          $('.service-lists-btn').on('click',function(event){
              event.preventDefault();

              $('.service-lists ul li a').removeClass('active');
              $object = $(this);
              var slug  = $(this).attr('data-type');
              var url = baseUrl+"/service/"+slug;


              $.ajax({
                  type: "get",
                  url: url,
                  data: {
                      slug: slug,

                  },
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
                  success: function (service) {
                      $object.addClass('active');
                      $('.service-lists-content').html(service);

                  },
                  error: function (e) {
                      if (e.responseJSON.message) {
                          swal('Error', e.responseJSON.message, 'error');
                      } else {
                          swal('Error', 'Something went wrong while processing your request.', 'error')
                      }
                  }
              });

          })

        });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>