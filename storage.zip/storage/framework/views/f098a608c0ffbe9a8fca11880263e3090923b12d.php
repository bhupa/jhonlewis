<div class="service-lists">
    <h2>Order Now</h2>

    <hr>

    <?php $__currentLoopData = $productlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-conten">
            <a href="<?php echo e(route('product.show',[$product->slug])); ?>">
                <div class="new"></div>

                <?php if(file_exists('storage/'.$product->image) && $product->image != ''): ?>
                    <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="<?php echo e($product->title); ?>">
                <?php endif; ?>
                <div class="product-overlay">
                                            <span class="product-content-span">
                                                <p>Price: <span class="product-overlay-item">£ <?php echo e($product->price); ?></span></p>
                                                <p>Size: <span class="product-overlay-item"><?php echo e($product->size); ?></span></p>
                                                <?php if(!empty($product->brand_id)): ?>
                                                <p>Brand: <span class="product-overlay-item"><?php echo e($product->brand->name); ?></span></p>
                                                <?php endif; ?>
                                            </span>

                </div>
                <p></p>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-view-more">Shop Online</a>

</div>