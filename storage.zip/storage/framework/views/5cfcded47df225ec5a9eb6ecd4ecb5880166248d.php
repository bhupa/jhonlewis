<?php $__env->startSection('title','Appointment-Lists'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Dashboard</h1>
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                <ul>
                                    <li><?php echo \Session::get('success'); ?></li>
                                </ul>
                            </div>

                        <?php endif; ?>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">

                            <li class="breadcrumb-item active">Dashboard </li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="single-table">
                    <div class="table-responsive">
                        <table class="table text-center" id="table">
                            <thead class="text-uppercase bg-primary">
                            <tr class="text-white">
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col" >Date</th>
                                <th scope="col" >Time</th>
                                <th scope="col" >Detail</th>
                                <th scope="col">action</th>
                            </tr>
                            </thead>
                            <tbody id="sortable">

                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="item-<?php echo e($item->id); ?>">
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($item->firstname); ?>-<?php echo e($item->lastname); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->phone); ?></td>

                                    <td><?php echo e(date('d-M-Y', strtotime($item->date))); ?></td>
                                    <td><?php echo e($item->time); ?></td>
                                    <td><?php echo e($item->details); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('appointments.edit', $item->id)); ?>" class="edit-modal btn btn-info btn-circle btn-sm"
                                           data-info="">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <a href="javascript:void(0)" id="reply-appointment-email" class="edit-modal btn btn-success btn-circle btn-sm"
                                           data-type="<?php echo e($item->id); ?>">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                        
                                        
                                        <a href="javascript:void(0)" class="delete-appointments btn btn-danger btn-circle btn-sm"
                                           data-type="<?php echo e($item->id); ?>">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- /.row -->
                <div class="appointment-details">

                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
    <script>
        $(document).ready( function () {

            $('#table').on('click','.delete-appointments',function(event){
                event.preventDefault();
                $object = $(this);
                var id  = $(this).attr('data-type');
                var url = baseUrl+"/appointments/"+id;
                swal({
                    title: 'Are you sure?',
                    text: 'You will not be able to recover this !',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, keep it'
                }).then((result) => {
                    if (result.value
                    )
                    {

                        $.ajax({
                            type: "Delete",
                            url: url,
                            data: {
                                id: id,
                                _method: 'DELETE'
                            },
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function (response) {
                                swal("Deleted!", response.message, "success");

                                var nRow = $($object).parents('tr')[0];
                                nRow.remove();
                            },
                            error: function (e) {
                                if (e.responseJSON.message) {
                                    swal('Error', e.responseJSON.message, 'error');
                                } else {
                                    swal('Error', 'Something went wrong while processing your request.', 'error')
                                }
                            }
                        });
                    }
                })
            })
            $('#table').on('click','#reply-appointment-email',function(event){
                event.preventDefault();
                $object = $(this);
                var id  = $(this).attr('data-type');
                var url = baseUrl+"/appointments/"+id;


                $.ajax({
                    type: "get",
                    url: url,
                    data: {
                        id: id,

                    },
                    dataType:'html',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (appointment) {
                        $('.appointment-details').html(appointment);
                        $('#appointment-emails').modal('show');
                    },
                    error: function (e) {
                        if (e.responseJSON.message) {
                            swal('Error', e.responseJSON.message, 'error');
                        } else {
                            swal('Error', 'Something went wrong while processing your request.', 'error')
                        }
                    }
                });

            })

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            

            $('#calendar').on('click','.event-date',function(event){
                event.preventDefault();
                //do whatever
                alert('hello');
            });

            $('.event-date').click(function(element) {
                element.preventDefault();
                alert('You clicked the link.');
                return false;
            });


        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>