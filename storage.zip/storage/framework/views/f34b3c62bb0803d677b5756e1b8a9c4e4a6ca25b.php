<?php $__env->startSection('title','Contact Us'); ?>
<?php $__env->startSection('css_script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="all">
        <div id="content">
            <div class="container">
                <div class="row">
                    
                        
                        
                            
                                
                                
                            
                        
                    
                    
                       
                    
                    <div class="col-lg-12">
                        <div id="contact" class="box" style="margin-top: 50px;">
                            <h1>Contact</h1>
                            <hr>
                            <div class="row">
                                <div class="col-lg-6">
                                    <h2>Contact Form</h2>
                                    <?php echo Form::open(['route'=>'contact-us.store','method'=>'post']); ?>

                                    <?php if(\Session::has('success')): ?>
                                        <div class="alert alert-success">

                                            <span><?php echo \Session::get('success'); ?></span>

                                        </div>

                                    <?php endif; ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="firstname">Firstname</label>
                                                <input id="firstname" name="firstname" type="text" class="form-control">
                                                <?php if($errors->has('firstname')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('firstname')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="lastname">Lastname</label>
                                                <input id="lastname" name="lastname" type="text" class="form-control">
                                                <?php if($errors->has('lastname')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('lastname')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="email">Email</label>
                                                <input id="email" type="text" name="email" class="form-control">
                                                <?php if($errors->has('email')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="subject">Subject</label>
                                                <input id="subject" name="subject" type="text" class="form-control">
                                                <?php if($errors->has('subject')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('subject')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="message">Message</label>
                                                <textarea id="message" name="message" class="form-control"></textarea>
                                                <?php if($errors->has('message')): ?>
                                                    <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-12 text-left">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Submit</button>
                                        </div>
                                    </div>
                                    <!-- /.row-->
                                    <?php echo Form::close(); ?>

                                </div>

                                <div class="col-lg-6 ">
                                    <div class="contact-page-right">
                                        <div class="col-md-12">

                                            
                                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($setting->slug == 'address'): ?>
                                                    <h3><i class="fa fa-map-marker" style="margin-right: 10px"></i><?php echo e($setting->value); ?></h3>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <!-- /.col-sm-4-->
                                        <div class="col-md-12">

                                            <p class="text-muted"></p>
                                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($setting->slug == 'phone'): ?>
                                                    
                                                    <h3><i class="fa fa-phone" style="margin-right: 10px"></i><?php echo e($setting->value); ?></h3>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <!-- /.col-sm-4-->

                                        <div class="col-md-12">
                                            
                                            <p class="text-muted">Please feel free to write an email to us or to use our electronic ticketing system.</p>
                                            <ul>
                                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($setting->slug == 'email'): ?>
                                                        <li><strong><a href="mailto:"><?php echo e($setting->value); ?></a></strong></li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <li><strong>

                                                        <?php if(Auth::check()): ?>
                                                            <a href="<?php echo e(route('appointment.index')); ?>">Appointment</a>

                                                        <?php else: ?>
                                                            <a href="javascript:void(0)" class="appointment-btn-modal" data-type="<?php echo e(route('appointment.index')); ?>">Appointment</a>

                                                        <?php endif; ?>

                                                    </strong> - You Can Appointment For Checkup</li>
                                            </ul>
                                        </div>
                                        <hr>
                                    </div>

                                    
                                        
                                            
                                                

                                                
                                            
                                        
                                    
                                </div>
                                <!-- /.col-sm-4-->
                            </div>


                            <!-- /.row-->

                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2484.2153447680557!2d0.06920631530132262!3d51.49091561973007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a8c1ceb86f69%3A0x5f31c5de7325f729!2sJohn%20Lewis%20Opticians!5e0!3m2!1sen!2snp!4v1592116587032!5m2!1sen!2snp" width="100%" height="450" frameborder="0" style="border:0; margin-top: 20px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

                        </div>


                    </div>

                    <!-- /.col-md-9-->

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>